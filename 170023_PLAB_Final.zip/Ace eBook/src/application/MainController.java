package application;

import java.io.*;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.ResourceBundle;
import java.util.Scanner;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

/***
 *The MainController is the FXML-Controller Class.
 */

/**
 * 
 * 
 * @author
 * Team 4 ZoomIn and ZoomOut functionality
 * Team 7 Editing EBook functionality
 * Team 8 GUI for EBook
 * Team 9 Sending Feedback Functionality
 * 
 * Managed By Jaskirat Singh Grewal
 * Integrated By Shivam Singhal, Sanchit, Sumit Singh
 */

public class MainController extends Application implements Initializable {

	public TextField text_1 = new TextField();
	public TextField text_2 = new TextField();
	public TextField text_3 = new TextField();
	
    @FXML
    private Button login;
    @FXML
    private TextField username;
    @FXML
    private PasswordField password;
    @FXML
    private RadioButton reader;
    @FXML
    private RadioButton author;
    @FXML
    private RadioButton admin;
    @FXML
    private Label message;
    @FXML
    private ComboBox<String> cb_roles;
    @FXML
    private TextField txt_userName;
    @FXML
    private PasswordField txt_password;
    @FXML
    private TextField txt_email;
    @FXML
    private PasswordField txt_confirmPassword;
    private ArrayList<String> userList = new ArrayList<String>();
    private ArrayList<String> passList = new ArrayList<String>();
    private ArrayList<String> emailList = new ArrayList<String>();
    @Override
    public void initialize(URL arg0, ResourceBundle arg1) {
        cb_roles.setPromptText("Select User");
        cb_roles.getItems().addAll("Reader", "Author", "Admin");
    }
    public enum EBMSHubs {
        AUTHOR_HUB,
        ADMIN_HUB,
        READER_HUB
    }
    private EBMSHubs currentlyCalledHub;

    /***
     * @author Jaskirat Singh Grewal (Team 9)
     * @throws IOException
     * Signup Window Backend Implementation
     */
    private void addNewAccount() throws IOException {

        String newUser = txt_userName.getText();
        String pass = txt_password.getText();
        String confirmPass = txt_confirmPassword.getText();
        String email = txt_email.getText();

        if (!pass.equals(confirmPass)) return;
        TextArea pseudoTextArea = new TextArea();
        Scanner scanner = new Scanner(new File("AccountDetails"));
        while (scanner.hasNext()) pseudoTextArea.setText(scanner.next());
        FileWriter fileWriter = new FileWriter(new File("AccountDetails"));
        fileWriter.write(pseudoTextArea.getText() + "\n");
        fileWriter.append(newUser + "\n" + pass + "\n" + email + "\n");
        fileWriter.close();
    }
    private void loadTheAccountData() throws FileNotFoundException {
        Scanner scanner = new Scanner(new File("AccountDetails"));
        while (scanner.hasNext()) {
            userList.add(scanner.next());passList.add(scanner.next());emailList.add(scanner.next());
        }
        scanner.close();
    }
    /***
     * @author Jaskirat Singh Grewal (Team-9)
     */
       public void launchRelevantWindow () throws FileNotFoundException {
           loadTheAccountData();
        String checkUserType = cb_roles.getSelectionModel().getSelectedItem();
        Hashtable<Integer,String> titleTable = new Hashtable<>();
        titleTable.put(1,"Reader's Hub");
        titleTable.put(2,"Author's Hub");
        titleTable.put(3,"Admin's Hub");
        String currentStageTitle = "";
        boolean userIsValidated = false;
        if (userList.contains(username.getText())&&passList.contains(password.getText())) {
            if (userList.indexOf(username.getText())==passList.indexOf(password.getText()))  {
                System.out.println("Re");
                userIsValidated= true;
            }
        }
      if (userIsValidated) {
          try {
              // Read file fxml and draw interface.
              FXMLLoader fxmlLoader;
              if (checkUserType.equals("Reader")) {
                  currentlyCalledHub = EBMSHubs.READER_HUB;
                  fxmlLoader = new FXMLLoader(getClass()
                          .getResource("/application/HomeWindow.fxml"));
                  currentStageTitle = titleTable.get(1);
              } else if (checkUserType.equals("Author")) {
                  currentlyCalledHub = EBMSHubs.AUTHOR_HUB;
                  fxmlLoader = new FXMLLoader(getClass()
                          .getResource("/application/AuthorHub.fxml"));
                  currentStageTitle = titleTable.get(2);
              } else {
                  currentlyCalledHub = EBMSHubs.ADMIN_HUB;
                  fxmlLoader = new FXMLLoader(getClass()
                          .getResource("/application/AdminHub.fxml"));
                  currentStageTitle = titleTable.get(3);
              }
              Parent root1 = (Parent) fxmlLoader.load();
              Stage mainStage = new Stage();
              mainStage.setTitle(currentStageTitle);
              mainStage.setScene(new Scene(root1));
              mainStage.show();

          } catch (Exception e) {
              e.printStackTrace();
              System.out.println("Can't Load the window");
          }
      }
      else message.setText("Invalid Credentials");
    }
    public void SignUp() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass()
                .getResource("/application/SignUp.fxml"));
        Parent root1 = (Parent) fxmlLoader.load();
        Stage mainStage = new Stage();
        mainStage.setTitle("Signing Up Window");
        mainStage.setScene(new Scene(root1));
        mainStage.show();
    }

    @Override
    public void start(Stage arg0) throws Exception {
        Parent root = FXMLLoader.load(getClass()
                .getResource("/application/LoginPage.fxml"));
        Stage primaryStage = new Stage();
        primaryStage.setTitle("eBook Software");
        primaryStage.setScene(new Scene(root));
        primaryStage.show();

    }

    public void openPopup(){
		
		Stage stage = new Stage(); // setting up the stage
		Pane pane = new Pane(); // defining the object for the pane
		stage.setTitle("PLAB_Final");
		
		Label lable1 = new Label();
		Label lable2 = new Label();
		Label lable3 = new Label();
		
		Label errorMessage = new Label("");
		
		errorMessage.setTextFill(Color.RED);
		
		errorMessage.setLayoutX(300);
		errorMessage.setLayoutY(230);
		
		lable1.setText("Enter Roll number :");
		
		lable1.setLayoutX(100);
		lable1.setLayoutY(100);
		
		text_1.setLayoutX(300);
		text_1.setLayoutY(100);
		
		lable2.setText("Enter two digit number :");
		
		lable2.setLayoutX(100);
		lable2.setLayoutY(200);
		
		text_2.setLayoutX(300);
		text_2.setLayoutY(200);
		
		
		text_2.setText("49");
		
		lable3.setText("After adding number is :");
		
		lable3.setLayoutX(100);
		lable3.setLayoutY(300);
		
		text_3.setLayoutX(300);
		text_3.setLayoutY(300);
		
		text_1.textProperty().addListener((observable, oldValue, newValue) -> {
			
			errorMessage.setText(checkNum(text_2.getText()));
			
			if(errorMessage.getText().length() == 0)     	text_3.setText(add(text_1.getText(),text_2.getText()));
		});
		
		text_2.textProperty().addListener((observable, oldValue, newValue) -> {
			
			errorMessage.setText(checkNum(text_2.getText()));
			
			if(errorMessage.getText().length() == 0)    	text_3.setText(add(text_1.getText(),text_2.getText()));
		    	
		});
		// add all the necessary elements in the pane
         pane.getChildren().addAll(text_1,text_2,text_3,lable1,lable2,lable3,errorMessage);

         Scene scene = new Scene(pane, 700, 700); // defing the height and width of the scene
         stage.setScene(scene);
         stage.show();
	}
    
   
    
    public static String add(String one, String two) {
    	
    	double num1 = Double.parseDouble(one);
    	double num2 = Double.parseDouble(two);
    	
    	double num3 = num1 + num2;
    	
    	return Double.toString(num3);    	
    	
    }
    
    public static String checkNum(String str) {
    	
    	if(str.length() !=2)
    		return "Number should of two digit only";
    	
    	else
    		return "";
    }
    
    public EBMSHubs getCurrentlyCalledHub() {
        return currentlyCalledHub;
    }
}
		
