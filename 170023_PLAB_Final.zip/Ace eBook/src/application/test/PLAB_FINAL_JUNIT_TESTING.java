package application.test;

import static org.junit.Assert.*;

import org.junit.Test;

import application.MainController;

public class PLAB_FINAL_JUNIT_TESTING {

	@Test
	public void testAdd() {
				
		String str = MainController.add("170023", "49");
				
		assertEquals(str, "170072.0");
	}
	
	@Test
	public void testcheckNum() {
		
		String str = MainController.checkNum("170023");
				
		assertEquals(str, "Number should of two digit only");
	}
}
